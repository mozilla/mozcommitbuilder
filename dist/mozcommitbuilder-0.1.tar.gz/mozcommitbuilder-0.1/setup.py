from distutils.core import setup
setup(name='mozcommitbuilder',
      version='0.1',
      py_modules=['mozcommitbuilder'],
      )
