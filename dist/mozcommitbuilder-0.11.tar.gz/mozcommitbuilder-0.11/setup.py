from distutils.core import setup
setup(name='mozcommitbuilder',
      version='0.11',
      py_modules=['mozcommitbuilder'],
      entry_points="""
          [console_scripts]
          mozcommitbuilder = mozcommitbuilder
        """
      )
